'use client'

import OneCIcon from '@/src/components/ui/icons/1CIcon'
import ArrowIcon from '@/src/components/ui/icons/ArrowIcon'
import LeftArrowIcon from '@/src/components/ui/icons/LeftArrowIcon'
import RightArrowIcon from '@/src/components/ui/icons/RightArrowIcon'
import StoreIcon from '@/src/components/ui/icons/StoreIcon'
import StudyIcon from '@/src/components/ui/icons/StudyIcon'
import { ROUTE_ITS, ROUTE_STORE, ROUTE_STUDY } from '@/src/routes'
import Link from 'next/link'
import { useState } from 'react'

const slides = [
	{
		title: 'ИТС',
		label: 'Сопровождение 1С',
		desc: 'Ваш ключ к актуальным обновлениям, круглосуточной поддержке и экономии ресурсов',
		icon: <OneCIcon width='156' height='100' color='#fff' />,
		to: ROUTE_ITS,
	},
	{
		title: 'Розница',
		label: 'Автоматизация магазина',
		desc: 'Система, которая упрощает работу и помогает зарабатывать больше',
		icon: <StoreIcon width='100' height='100' color='#fff' />,
		to: ROUTE_STORE,
	},
	{
		title: 'Курсы',
		label: 'профессиональной подготовки по 1С',
		desc: 'Стать экспертом в работе с 1С — повысить свою конкурентоспособность и овладеть востребованными навыками',
		icon: <StudyIcon width='100' height='100' color='#fff' />,
		to: ROUTE_STUDY,
	},
]

export default function Hero() {
	const [active, setActive] = useState(0)

	const prev = () => setActive(i => (i === 0 ? slides.length - 1 : i - 1))
	const next = () => setActive(i => (i === slides.length - 1 ? 0 : i + 1))

	const slide = slides[active]

	return (
		<section className='relative min-h-screen pt-17 flex flex-col justify-center overflow-hidden'>
			{/* Background glow */}
			<div
				className='absolute inset-0 pointer-events-none'
				style={{
					background:
						'radial-gradient(ellipse 70% 60% at 70% 40%, rgba(29,111,232,0.12) 0%, transparent 60%), radial-gradient(ellipse 40% 50% at 15% 70%, rgba(0,210,255,0.06) 0%, transparent 55%)',
				}}
			/>
			{/* Grid pattern */}
			<div className='absolute inset-0 pointer-events-none bg-hero-grid' />

			<div className='max-w-300 mx-auto px-8 md:px-12 w-full'>
				<div className='grid grid-cols-1 lg:grid-cols-[1fr_420px] gap-16 xl:gap-20 items-center py-20'>
					{/* Left */}
					<div>
						<div className='inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-brand-blue/10 border border-brand-blue/35 text-brand-blue-light text-[13px] font-medium mb-7'>
							<span className='w-1.5 h-1.5 rounded-full bg-brand-blue-light animate-pulse' />
							Официальный представитель 1С
						</div>

						<h1 className='font-display text-[clamp(36px,4vw,58px)] font-bold leading-[1.12] tracking-tight mb-6'>
							Умные решения
							<br />
							для{' '}
							<span className='text-brand-blue-light'>умных</span>
							<br />
							компаний
						</h1>

						<p className='text-[18px] text-[#8B9EB7] leading-relaxed max-w-130 mb-10'>
							С Нами вам доступен полноценный комплекс IT-услуг:
							от бесплатной консультации до установки, настройки,
							обучения и постоянного сопровождения.
							<br />
							Работаем так, чтобы вам не пришлось ни о чём
							беспокоиться.
						</p>

						<div className='flex flex-wrap gap-4'>
							<Link
								href='#cta'
								className='inline-flex items-center px-8 py-3.5 rounded-xl bg-brand-blue text-white text-base font-semibold hover:bg-brand-blue-light hover:-translate-y-0.5 transition-all duration-200 no-underline'
							>
								Бесплатная консультация
							</Link>
							<Link
								href='#products'
								className='inline-flex items-center px-8 py-3.5 rounded-xl bg-transparent text-[#EEF2FF] text-base font-semibold border border-white/13 hover:border-brand-blue/35 hover:text-brand-blue-light transition-all duration-200 no-underline'
							>
								Каталог продуктов
							</Link>
						</div>
					</div>

					{/* Slider */}
					<div className='flex flex-col gap-4'>
						{/* Slide card */}
						<Link
							href={slide.to}
							className='relative bg-white/4 border border-white/13 rounded-2xl p-8 backdrop-blur-md overflow-hidden h-100 flex flex-col justify-between cursor-pointer hover:border-brand-blue-light transition-colors duration-200'
						>
							{/* Subtle glow behind number */}
							<div
								className='absolute -top-8 -right-8 w-40 h-40 rounded-full pointer-events-none'
								style={{
									background:
										'radial-gradient(circle, rgba(29,111,232,0.18) 0%, transparent 70%)',
								}}
							/>

							<div>
								{/* Icon */}
								<div className='w-40 h-36 rounded-xl bg-brand-blue/10 border border-white/13 flex items-center justify-center text-brand-blue-light mb-6 p-5'>
									{slide.icon}
								</div>

								{/* Title */}
								<div className='font-display text-[48px] font-bold text-brand-blue-light leading-none mb-2'>
									{slide.title}
								</div>

								{/* Label */}
								<div className='text-[15px] font-semibold text-[#EEF2FF] mb-3'>
									{slide.label}
								</div>

								{/* Description */}
								<p className='text-[14px] text-[#8B9EB7] leading-relaxed'>
									{slide.desc}
								</p>

								<div className='absolute bottom-5 right-5 text-[#4D6280]'>
									<ArrowIcon />
								</div>
							</div>
						</Link>

						{/* Controls */}
						<div className='flex items-center justify-between'>
							{/* Dots */}
							<div className='flex items-center gap-2'>
								{slides.map((_, i) => (
									<button
										key={i}
										onClick={() => setActive(i)}
										aria-label={`Слайд ${i + 1}`}
										className={`rounded-full transition-all duration-300 cursor-pointer ${
											i === active
												? 'w-6 h-2 bg-brand-blue-light'
												: 'w-2 h-2 bg-white/20 hover:bg-white/40'
										}`}
									/>
								))}
							</div>

							{/* Prev / Next */}
							<div className='flex items-center gap-2'>
								<button
									onClick={prev}
									aria-label='Предыдущий слайд'
									className='w-10 h-10 rounded-xl flex items-center justify-center border border-white/13 text-[#8B9EB7] hover:border-brand-blue/35 hover:text-brand-blue-light hover:bg-brand-blue/10 transition-all duration-200 cursor-pointer'
								>
									<LeftArrowIcon />
								</button>
								<button
									onClick={next}
									aria-label='Следующий слайд'
									className='w-10 h-10 rounded-xl flex items-center justify-center border border-white/13 text-[#8B9EB7] hover:border-brand-blue/35 hover:text-brand-blue-light hover:bg-brand-blue/10 transition-all duration-200 cursor-pointer'
								>
									<RightArrowIcon />
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	)
}
